file path--consistent name--return type--{paratype1-paratype2...}
E.g.,
hive/ql/src/java/org/apache/hadoop/hive/ql/exec/persistence/MapJoinKeyObject.java--write--void-- { MapJoinObjectSerDeContext-ObjectOutputStream- }